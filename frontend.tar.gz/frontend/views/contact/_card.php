<address>
  <abbr title="Telehone">Phone:</abbr><?= $model['telephone'] ?><br>
  <abbr title="Mobile Number">Mobile:</abbr><?= $model['mobilephone'] ?><br>
  <abbr title="Postal Address:">Postal:</abbr><?= $model['postal_address'] ?><br>
</address>
