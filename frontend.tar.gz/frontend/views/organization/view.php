<?php

use yii\helpers\Html;
use yii\widgets\DetailView;
use kartik\tabs\TabsX;

/* @var $this yii\web\View */
/* @var $model app\models\Organization */

$this->title = $model->name;
$this->params['breadcrumbs'][] = ['label' => 'Organizations', 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;

$contacts = Yii::$app->controller->renderPartial('@app/views/contact/_view',[
  'model' => $model->getContacts()->one(),
]);

$service_offer = Yii::$app->controller->renderPartial('@app/views/organization-service-offer/_list',[
  'service_offers' => $model->organizationServiceOffersList,
]);

$hotel_room = Yii::$app->controller->renderPartial('@app/views/hotel-room/list',[
    'organization_id' => $model->id,
    'dataProvider' => new \yii\data\ActiveDataProvider([
        'query' => $model->getHotelRooms(),
        'pagination' => false
        ]),
]);

?>
<div class="organization-view" id="organization-view">

    <h1><?= Html::encode($this->title) ?></h1>

    <?php if (\Yii::$app->user->can('hotel_admin')) : ?>
      <div class="btn-toolbar" role="toolbar" >
        <div class="btn-group">
          <?= Html::a('<i class="fa fa-pencil"></i>', ['update', 'id' => $model->id], ['class' => 'btn btn-primary', 'title'=>"Update"]) ?>
          <?= Html::a('<i class="fa fa-print"></i>', ['report', 'id' => $model->id], ['class' => 'btn btn-default', 'title'=>"Print"]) ?>
        </div>
      </div><br>
    <?php endif; ?>

    <div class="panel panel-default">
      <div class="panel-body">
        <div>
          <h3 style="padding-left:25px;"><?= $model->name; ?></h3>
        </div>
        <div class="row">
          <div class="col-md-8">
            <div class="panel panel-default" id="thumbnail-panel">
              <div class="panel-body">
                <p class="thumbnail">
                  <img src="<?= $model['picture'] ?>" alt="<i class='fa fa-ticket'> Bookeezz!</i>" class="img-thumbnail" style="height: 200px; width: auto; display: block;">
                </p>
              </div>
            </div>
            <div class="panel panel-default" id="description-panel">
              <div class="panel-body">
                <?= Yii::$app->formatter->asHtml($model->description) ?>
              </div>
            </div>
          </div>
          <div class="col-md-4">
            <div class="panel panel-default" id="contacts">
              <?php if (\Yii::$app->user->can('hotel_admin')) : ?>
                <div class="panel-heading">
                    <div class="btn-group">
                      <?= Html::a('<i class="fa fa-pencil"></i>', ['contact/index', 'ContactSearch[organization_id]' => $model->id], ['class' => 'btn btn-primary', 'title'=>"Update"]) ?>
                    </div>
                </div>
              <?php endif; ?>
              <div class="panel-body">
                <p><?= $contacts ?></p>
                <p><?= $service_offer ?></p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

</div>

<div id="hotel-room">
  <h4>Rooms</h4>
  <?= $hotel_room ?>
</div>
