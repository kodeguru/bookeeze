<?php
use yii\helpers\Html;
?>
<p>
    <?= Html::a('Report', ['report', 'id' => $id], ['class' => 'btn btn-primary', 'target'=>'_blank']) ?>
</p>
